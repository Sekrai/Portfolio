#include <iostream>
#include <stdlib.h>
#include <filesystem>
#include "TGA.h"

std::string FindFileName(std::string aFilePath)
{
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	_splitpath_s(aFilePath.c_str(), drive, dir, fname, ext);
	std::string tempFileName = fname;

	return tempFileName;
}

int main(int argc, char* argv[])
{
	std::filesystem::path tempPath = std::filesystem::current_path();

	std::string tempImagePath = tempPath.string() + "\\SampleImages\\JustRight.tga";
	std::string tempDestinationPath = tempPath.string() + "\\SampleImages\\BlurredImage.tga";
	double tempBlurFactor = 5;

	if (argc > 1)
	{
		char tempInput = 'n';
		std::string tempArgumentChange;
		int tempIndex = 0;

		std::cout << "These are the specified Arguments:" << std::endl;

		for (int i = 1; i < argc; i++)
		{
			if (i == 1)
			{
				tempImagePath = argv[i];
			}
			else if (i == 2)
			{
				tempDestinationPath = argv[i];
				std::string tempFileName = FindFileName(tempImagePath);

				tempDestinationPath += tempFileName + "Blurred.tga";
			}
			else if (i == 3)
			{
				tempBlurFactor = std::stod(argv[i]) * 10;
			}

			std::cout << i << ": " << argv[i] << std::endl;
		}


		std::cout << "Would you like to change any of the arguments? y/n" << std::endl;
		
		std::cin >> tempInput;

		while (tempInput == 'y' || tempInput == 'Y')
		{
			std::cout << "Which argument would you like to change?" << std::endl;
			
			do
			{
				std::cout << "Enter the index of the argument you wish to change" << '\r' << std::endl;
				std::cin >> tempIndex;
			} while (tempIndex <= 0 || tempIndex >= argc);

			std::cout << "Insert a new value for the chosen argument" << std::endl;
			std::cin >> tempArgumentChange;

			if (tempIndex == 1)
			{
				tempImagePath = tempArgumentChange;
			}
			else if (tempIndex == 2)
			{
				tempDestinationPath = tempArgumentChange;

				std::string tempFileName = FindFileName(tempImagePath);
				tempDestinationPath += tempFileName + "Blurred.tga";
			}
			else if (tempIndex == 3)
			{
				tempBlurFactor = std::stod(tempArgumentChange) * 10;
			}
			else
			{
				std::cout << "There's no valid argument to change" << std::endl;
			}

			std::cout << "Would you like to change another argument? y/n" << std::endl;

			std::cin >> tempInput;
		}
	}

	TGA tempImage = TGA(tempImagePath.c_str());


	tempImage.Blur(tempBlurFactor);


	if (tempImage.Save(tempDestinationPath.c_str()) == true)
	{
		std::cout << "Output Image Finished with a total blur scale of: " << (tempBlurFactor / 10) << std::endl;
	}
}