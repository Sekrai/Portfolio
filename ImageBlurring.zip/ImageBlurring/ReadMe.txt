Compiler & Version: Visual Studio 2019 version 16.8.2
Linker Settings: C++ Language Standard set to ISO C++ 17 Standard (/std:c++17) (I used C++ 17 for Filesystem in order to get a viable path in case the program is run without any command lines)


I started out with researching different Blurring Algorithms to get a good grasp of the task I had ahead of me.
That's when I came across this blog post that had detailed comparisons of several useful algorithms.
Bluring Alghoritms: http://blog.ivank.net/fastest-gaussian-blur.html
This research took me around 1~2 hours but is hard to evaluate since I researched it whenever I had time to spare between work.

The next step was refreshing my memory on passing arguments via command-lines which was a 5~10 min read, mostly since it's not something I've had to use and only knew the theory of.

Once I had settled the different algorithms and how to pass arguments I sunk 2~ hours into reading up on TGA-files and attempting various implementations of a TGA reader, finally settling on one.
After I found a suitable way to load my files I spent 30~45 min making a decent TGA-writer.
The TGA-reader can handle both 24 and 32 bit files so use whichever you feel like.
The total effective work that went into the file reading and writing is around 3~ hours.

Once I was satisfied with how my program could read and write TGA-files I began implementing my Blurring algorithms, starting off with the Gaussian Blurr.

There's a total of 3 algorithms in my program and I left them all in since you might want to use them in different situations.
The Gaussian Blur is the slowest but most accurate algorithm, when I realized that it takes the Gaussian Blur around 2 min to finish blurring at a satisfactory scale to make it "Blurred Beyond Recognition" I went on to implement the Box Blur.
The Box Blur Reduced the effective run time to around 45~ seconds and still maintains a satisfactory blurriness.
After this I went ahead and implemented the "Horizontal/Total Box Blur" or as I just called it "Horizontal/Vertical Box Blur" which is just a way to split up the Box blur in 2 steps, this reduced the effective run time to around 4~ seconds.
The effective run times are estimates on my hardware with a 9700 i7 intel CPU, your times may differ.
So the Algorithm that runs by default is the "Horizontal/Vertical Box Blur" since that's the fastest by far and stays very close to the original Box Blur in how blurry things get.
Worth mentioning is that at the moment I run both Box Blurs three times to reach the same approximate blur as the Gaussian Blur does.

Implementing the different bluring algorithms took around 1~2 hours, this coupled with the research that went into the various algorithms makes the total Blur algorithm work time closer to 3~4 hours.

Once I was satisfied with how my program ran I spent around 1~ hour making it more user friendly by implementing some fail-safe's in case the program is run without Command-Lines, if the wrong command lines are passed or if you just change your mind after starting up the program.
As mentioned above this is where I use the Filesystem in order to allow the program to be run without any command-lines and this is also the reason I included a couple images in the turn-in folder.

The total work time on this project clocked in at around 7~8 hours, this includes the various Research I had to do and the extra implementations. 
I believe I could've reduced the effective work time to around 6~7 hours if I had settled on only one algorithm and had the opportunity to work with this without interruptions.



Program runtime Step by Step:

1. The program starts up and finds a suitable path in case no command lines were given, creating default values.
2. After that the program goes on to check how many arguments were passed and begins to list them as well as changing the default values to whatever command-lines were passed.
2a. Command lines should be passed in order: Source-image, Destination-image, Blur-factor
3. Then it asks the user if there's any changes they wish to make, simply return 'n' to continue if you're satisfied with the paths and blur factor.
4. Once all the paths are set the program creates a TGA instance that takes the image path and opens up the header.
5. It checks if the file is compressed or not and depending on what state the file is in it does one of two things:
	5a. Decompressed: It sets the various header variables with the appropriate header information read from the header. It then opens up and saves all the image data as is.
	5b. Compressed: It reads the header information the same way as the Decompressed version, then allocates enough memory to fit the new decompressed file, then it goes on to decompress the image in chunks. 
		All this assumes that the TGA is compressed with RLE.
6. Once the image has been loaded the program goes on to run the blurring algorithm, the default is set to "Horizontal/Vertical Box Blur" which gets called in the Blur-method.
6a. The Blur method starts with calculating the boxes of which the Box Blur will base it's blurring off of.
6b. Then depending on the specified depth the Box Blur will run, in this case 3 times, alternating between Horizontal and Vertical.
6c. The Horizontal Blur goes over each pixel a number of steps from left to right of the current pixel equal to the chosen scale and then takes the average color data of all those pixels (Adds them together and divides with the number of pixels that were checked). The Vertical does the same but from Top to Bottom instead of from left to right.
7. Once the blur is done it goes on to save the file in an uncompressed state.
7a. First it creates a file at the specified path, after this is done it creates a header with the previous specified header information. It then writes the header and image data to the file and then adds a footer before closing the file and returning true to signify that the file was created successfully.
8. The program lets you know that it ran successfully and then you can find the blurred file where you specified!



I just want to say that this was a fun quiz and if nothing else I am happy that I had the opportunity to do it!
If there's anything missing or anything that's unclear I'll gladly clarify to the bets of my ability!